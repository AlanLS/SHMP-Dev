/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */



public class KernelConstants {
    
    public static byte BACKEND_APPHANDLER = 0;
    
    public static byte BACKEND_PROFILEHANDLER = 1;
    
    public static byte BACKEND_SMSREADER = 2;
    
    public static byte BACKEND_SECURITY = 3;

    public static byte BACKEND_ADDHANDLER = 4;
    
    public static byte BACKEND_DOWNLOADHANDLER = 5;
    
    public static byte FRENDEND_PROFILE = 0;
    
    public static byte FRENDEND_MENU = 1;
    
    public static byte FRENDEND_ENTRY = 2;
    
    public static byte FRENDEND_DISPLAY = 3;
    
    public static byte FRENDEND_INBOX = 4;
    
    public static byte FRENDEND_VIEW = 5;
    
    public static byte FRENDEND_DOWNLOAD = 6;
    
    public static byte FRENDEND_FLASH = 7;

    public static byte FRENDENT_CHAT = 8;
}

