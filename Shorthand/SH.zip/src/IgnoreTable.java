public class IgnoreTable {

    private String stText;
    
    private String edText;
    
    public IgnoreTable(String sT,String eT){
        stText = sT;
        edText = eT;
    }

    public String getEdText() {
        return edText;
    }

    public String getStText() {
        return stText;
    }
    
    
    
}