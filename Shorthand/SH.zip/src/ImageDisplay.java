
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Timer;
import java.util.TimerTask;
import javax.microedition.io.Connector;
import javax.microedition.io.HttpConnection;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;
import javax.microedition.media.Manager;
import javax.microedition.media.MediaException;
import javax.microedition.media.Player;
import javax.microedition.media.PlayerListener;
import javax.microedition.media.control.VolumeControl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sasi
 */
public class ImageDisplay implements PlayerListener{

    private Timer rotateImageTimer = null;

    private int imgrotType = 0;

    private byte rStart = 0;
    
    private String sHeader = null;

    private String imageId = null;

    private String fileLocation = null;

    private boolean isImageSend =  false;

    private boolean isAudio = false;

    private Player player = null;

    private boolean playAudio = false;

    public boolean setHeadetText(String hText,
            String imageId, String fileLocation, byte screenType){
        boolean isShow = false;
        isAudio = false;
        playAudio = false;
        byte downloadStart = 0;
        if(screenType == 0 || screenType == 2){ //Download Image/Audio From imageId and show
            if(screenType == 0){
                downloadStart = setImage(fileLocation);
            } else {
                isAudio = true;
                downloadStart = setAudio(fileLocation);
            }
            if(downloadStart == 0){
                DownloadHandler downloadHandler = new DownloadHandler();
                if(screenType == 2){ //Download Audio //CR 14492
                    downloadHandler.downloadImage(null,imageId,true);
                } else downloadHandler.downloadImage(null,imageId,false); //Download Image
                downloadHandler = null;
            }
        } else if(screenType == 1){ //Show image from fileLocation
            //Show image and upload image from fileLocation
            downloadStart = setImage(fileLocation);
        }  
        if(downloadStart  > -1){
            isShow = true;
            sHeader = hText;
            deInitialize();
            if(downloadStart == 0){
                startRotateImateTimer();
            }
            this.imageId = imageId;
            this.fileLocation = fileLocation;
            CustomCanvas.sHeader = CustomCanvas.getSecondaryHeader(sHeader, "",0);
            ShortHandCanvas.IsNeedPaint();
        }
        return isShow;
    }

    //CR 14492
    private byte setAudio(String fileLocation){
        byte downloadStart = -1;
        if(null != fileLocation){
            boolean isNotSecurity = CustomCanvas.setAudioFile(fileLocation);
            if(isNotSecurity){
                if(null != UiGlobalVariables.byteArrayInputStream){
                    downloadStart = 1;
                }  else {
                    downloadStart = 0;
                }
            }
        } else {
            UiGlobalVariables.imagefile = null;
            downloadStart = 0;
        }
        return downloadStart;
    }

    //Cr 14423
    private byte setImage(String fileLocation){
        byte downloadStart = -1;
        if(null != fileLocation){
            boolean isNotSecurity = CustomCanvas.getFileImage(fileLocation);
            if(isNotSecurity){
                if(null != UiGlobalVariables.imagefile){
                    downloadStart = 1;
                }  else {
                    downloadStart = 0;
                }
            } 
        } else {
            UiGlobalVariables.imagefile = null;
            downloadStart = 0;
        }
        return downloadStart;
    }

    public boolean isWait(){
        return isImageSend;
    }

    private void rotateImage(){
        rStart++;
        if(rStart >= 5){
            imgrotType++;
            if (imgrotType > 3) {
                imgrotType = 0;
            }
            rStart = 0;
        }
    }

    public byte isBack(int keyCode){
        byte back = 0;
        if(UISettings.RIGHTOPTION == keyCode ){
            if(UISettings.rOByte>-1){
                ShortHandCanvas.IsNeedPaint();
                back = 1;
            }
        } else if(UISettings.LEFTOPTION == keyCode){
            if(UISettings.lOByte == 54){
                back = 2;
                isImageSend = true;
                startRotateImateTimer();
                DownloadHandler downloadHandler = new DownloadHandler();
                downloadHandler.downloadImage(fileLocation,imageId , false);
                downloadHandler = null;
            }
        }
        return back;
    }

    public String getFileLocation(){
        return fileLocation;
    }

    /**
     * Method to unload the canvas
     */
    public void unLoad() {
        deInitialize();
    }

    //CR 13900
    //CR 13981
    public void drawDisplayImage(Graphics graphics) {
        if(isAudio){
            if(!playAudio){
                if(null == UiGlobalVariables.byteArrayInputStream){
                    CustomCanvas.drawProcessImage(graphics,imgrotType);
                } else {
                    Logger.loggerError("Player initialize");
                    playAudio = true;
                    if(null != UiGlobalVariables.audioExtension){
                        playAudio();
                    } else Logger.loggerError("Extension null");
                }
            }
        } else {
            if(null == UiGlobalVariables.imagefile || isImageSend){
                CustomCanvas.drawProcessImage(graphics,imgrotType);
            } else {
                int yPosition = (UISettings.headerHeight+UISettings.secondaryHeaderHeight);
                int height = UISettings.formHeight - (yPosition+UISettings.footerHeight+graphics.getFont().getHeight()+4);
                if(null != UiGlobalVariables.imagefile){
                    if(UiGlobalVariables.imagefile.getHeight()<height)
                        yPosition += (height-UiGlobalVariables.imagefile.getHeight())/2;
                    graphics.drawImage(UiGlobalVariables.imagefile, (UISettings.formWidth-
                            UiGlobalVariables.imagefile.getWidth())/2, yPosition, Graphics.TOP|Graphics.LEFT);
                } else{
                    graphics.setColor(0xd3d3d3);
                    graphics.fillRect(10, yPosition, UISettings.formWidth-20,height);
                }
            }
        }
    }

    private void playAudio(){
        Logger.loggerError("PlayAudio "+UiGlobalVariables.audioExtension);
        SoundManager.getInstance().deinitialize();
//        try{
//            player = Manager.createPlayer(UiGlobalVariables.byteArrayInputStream, "audio/"+UiGlobalVariables.audioExtension);
//        }catch(MediaException mediaException){
//            try{
//                player = Manager.createPlayer(UiGlobalVariables.byteArrayInputStream, "audio/x-"+UiGlobalVariables.audioExtension);
//            }catch(Exception exception){
//                Logger.loggerError("Second Player Initilaize Error "+exception.toString());
//            }
//        } catch(SecurityException securityException){
//            Logger.loggerError("Player Initialize Security Exception"+securityException.toString());
//        }
//        catch(Exception exception){
//            Logger.loggerError("First Player Initialize Error "+exception.toString());
//        }hema
        UiGlobalVariables.byteArrayInputStream.reset();
        try{
           // if(UiGlobalVariables.audioExtension.startsWith("amr"))
             //   player=Manager.createPlayer(UiGlobalVariables.byteArrayInputStream, "audio/amr");// + UiGlobalVariables.audioExtension);
            // else
                player=Manager.createPlayer(UiGlobalVariables.byteArrayInputStream, "audio/"+UiGlobalVariables.audioExtension);
                   Logger.debugOnError("playing from stream:"+ UiGlobalVariables.audioExtension);
        }
        catch(Exception exc){
            Logger.debugOnError("playing input stram fail and trying direct server link "+exc);
//        try{
//                    HttpConnection conn = (HttpConnection)Connector.open(UiGlobalVariables.audioExtension, 
//                        Connector.READ_WRITE);
//                    InputStream is = conn.openInputStream();
//                    player = Manager.createPlayer(is,"audio/X-wav");
//            
//        }
//        catch(Exception ex)
//        {
//            Logger.debugOnError("playing server audio error "+ex);
//        }
        }
//        UiGlobalVariables.audioExtension = null;
        try{
            if(null != player){
                player.addPlayerListener(this);//maliHEMA
                player.realize();
                VolumeControl volumeControl = (VolumeControl) player.getControl("VolumeControl");
                if(null != volumeControl){
                    volumeControl.setLevel(100);
                }
                player.start();
//                UiGlobalVariables.byteArrayInputStream.close();
//                UiGlobalVariables.byteArrayInputStream = null;
//                UiGlobalVariables.inputStream.close();
//                UiGlobalVariables.inputStream = null;
               // return;HEMA
            }
        }catch(Exception exception){
            Logger.loggerError("Player Start Error "+exception.toString());
            player= null;
            UiGlobalVariables.byteArrayInputStream.reset();
            try{
            player=Manager.createPlayer(UiGlobalVariables.byteArrayInputStream, "audio/amr");
                   Logger.debugOnError("playing from stream2:");
                   if(null != player){
                       player.realize();
                       VolumeControl volumeControl = (VolumeControl) player.getControl("VolumeControl");
                if(null != volumeControl){
                    volumeControl.setLevel(100);
                }
                       player.start();
                   }
        }
            catch(Exception ex){
                   Logger.debugOnError("playing from stream2:err"+ex);

            }
            
        }
        finally{
            try {
                UiGlobalVariables.byteArrayInputStream.close();
                 UiGlobalVariables.byteArrayInputStream = null;
            } catch (IOException ex) {
            }
                
            
        }
    }

    private void stopRotateImageTimer(){
        if(null != rotateImageTimer){
            rotateImageTimer.cancel();
            rotateImageTimer = null;
        }
    }


    private void startRotateImateTimer(){
        rotateImageTimer = new Timer();
        rotateImageTimer.schedule(new DisplayImageTimer(), 0, 100);
    }

    public void rotateScreen(boolean isLandScape) {
        CustomCanvas.sHeader = CustomCanvas.getSecondaryHeader(sHeader, "",0);
    }


    /**
     * De Initialize method
     */
    public void deInitialize() {

        stopRotateImageTimer();

        rStart = 0;

        //Int
        imgrotType = 0;
        isImageSend = false;

    }


    //CR 14423
    public String  setImage(byte[] writeByte, boolean isStore){
        String fileLocation = null;
         ByteArrayInputStream in= null;
        if(isAudio){
            Logger.debugOnError("set file bytes:"+writeByte.length);
            if(isStore){
                deInitialize();
                try{
                  
                UiGlobalVariables.byteArrayInputStream = new ByteArrayInputStream(writeByte);
                                 in = new ByteArrayInputStream(writeByte);

               // UiGlobalVariables.byteArrayInputStream.reset();

                //UiGlobalVariables.byteArrayInputStream.read(writeByte, 0, writeByte.length);
                }
                catch(Exception ex)
                {
                   // String e=ex;
                }
               // UiGlobalVariables.audioExtension = "wav";
                fileLocation = Utilities.saveImage_Audio(in,
                            imageId, false, UiGlobalVariables.audioExtension);
//               UiGlobalVariables.audioExtension = "wav";
//                fileLocation = Utilities.saveImage_Audio(UiGlobalVariables.byteArrayInputStream,
//                            imageId, false, UiGlobalVariables.audioExtension);
//                                Hema

            }
        } else {
            try {
                //CR 13981
                UiGlobalVariables.imagefile = Image.createImage(writeByte, 0, writeByte.length);
                fileLocation = "";
            } catch (Exception e) {
                Logger.debugOnError("Caption Image Create Error " + e.toString());
                try {
                    if (writeByte[0] == 0xFF && writeByte[1] == 0xD8) {
                        UiGlobalVariables.imagefile = Image.createImage(writeByte, 1, writeByte.length);
                    }
                    fileLocation = "";
                } catch (Exception ex) {
                    Logger.debugOnError("Caption Image Create Error " + ex.toString());
                }
            }
            if(null != fileLocation){
                deInitialize();
                if(isStore){
                    String image = Utilities.saveImage_Audio(new ByteArrayInputStream(writeByte),
                            imageId, true, "jpeg");
                    if(null != image){
                        fileLocation = image;
                    }
                }
            }
        }
        return fileLocation;
    }

    private void stopPlayer(){
            try{
            if(null != player){
                if(player.getState() == Player.STARTED){
                    player.stop();
                }
//                if(player.getState() == Player.PREFETCHED){
                    player.deallocate();
//                }
                if(player.getState() == Player.REALIZED  || player.getState() == Player.UNREALIZED){
                    player.close();
                }
                player = null;
            }
        }catch(Exception exception){
            Logger.loggerError("CaptureImage->stopPlayer->Player"+exception.toString());
        }
    }

    public void playerUpdate(Player player, String event, Object o) {
        if (event.compareTo(PlayerListener.END_OF_MEDIA) == 0) {
            stopPlayer();
        }
    }

    

     class DisplayImageTimer extends TimerTask{
        public void run(){
            rotateImage();
            ShortHandCanvas.IsNeedPaint();
        }
    }
}
