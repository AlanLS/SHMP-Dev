package generated;


public interface AnimSmart
{ 

}
