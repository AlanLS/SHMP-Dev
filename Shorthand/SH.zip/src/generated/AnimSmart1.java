package generated;


public interface AnimSmart1
{ 

}
