package generated;


public interface GobSmart
{ 
	int BG = 0;
	int IS = 1;
	int HD = 2;
	int HG = 3;
	int HG1 = 4;
	int HG2 = 5;
	int HG3 = 6;
	int MSG = 7;
	int MSG1 = 8;
	int MSG2 = 9;
	int MSG3 = 10;
	int SHD = 11;
	int RD = 12;
	int UR = 13;

}
