package generated;


public interface AnimSplash
{ 

}
