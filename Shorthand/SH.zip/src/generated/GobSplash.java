package generated;


public interface GobSplash
{ 
	int SPLASH = 0;

}
