package generated;


public interface GobSmart1
{ 
	int SMS = 0;
	int DATA = 1;
	int CIRCLE = 2;
	int _1 = 3;
	int _2 = 4;
	int _3 = 5;
	int _4 = 6;
	int _5 = 7;
	int _6 = 8;
	int _7 = 9;
	int _8 = 10;
	int _9 = 11;
	int _10 = 12;
	int SCROLL = 13;

}
