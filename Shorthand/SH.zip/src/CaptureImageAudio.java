
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.Calendar;
import java.util.Timer;
import java.util.TimerTask;
import javax.microedition.lcdui.Graphics;
import javax.microedition.media.Manager;
import javax.microedition.media.MediaException;
import javax.microedition.media.Player;
import javax.microedition.media.control.RecordControl;
import javax.microedition.media.control.VideoControl;

/**
 *
 * @author sasi
 */
public class CaptureImageAudio implements ICaptureImage {

    private Player player = null;

    private VideoControl videoControl = null;
    
    private boolean isCurrentScreen = false;

    private Timer rotateImageTimer = null;

    private int imgrotType = 0;

    private byte rStart = 0;

    private boolean isUpload = false;

    private String chatId = null;

    private boolean isCamera = false;

    private IMenuHandler iMenuHandler = null;

    private RecordControl recordControl = null;

    private boolean isImage = false;

    private ByteArrayOutputStream byteArrayOutputStream = null;

    private boolean isAudio = false;

    private long totoalTime = 0;

    public CaptureImageAudio(IMenuHandler iMenuHandler) {
        this.iMenuHandler = iMenuHandler;
    }

    public void setChatId(String chatId){
        this.chatId = chatId;
    }

    public boolean isCurrentScreen(){
        return isCurrentScreen;
    }

    public boolean isCameraScreen(){
        return isCamera;
    }

    private void getSupportContentType(){
        String[] value = Manager.getSupportedContentTypes("capture");
        if(null != value){
            for(int i=1;i<value.length;i++){
                value[0] += value[i];
            }
            Logger.loggerError("Video Supported Format-> "+value[0]);
        } else Logger.loggerError("No Video Supported Format");
    }


    private boolean isCaptureImage(){
        boolean isVideo = true;
        try {
            getSupportContentType();
            String model = Utilities.getManufacture();
            if((null != model && model.toLowerCase().indexOf("samsung")>-1)
                    || Utilities.isCameraVideoSupport()){
                isVideo = false;
                player = Manager.createPlayer("capture://video");
            } else {
                player = Manager.createPlayer("capture://image");
            }
	} catch (MediaException mediaException) {
            Logger.loggerError("CaptureImage->isCapture->capture://video"+mediaException.toString());
	    try {
                if(isVideo){
                    player = Manager.createPlayer("capture://video");
                } else {
                    player = Manager.createPlayer("capture://image");
                }
	    } catch (Exception exception) {
                Logger.loggerError("CaptureImage->isCapture->capture://image"+exception.toString());
	    }
	} catch (Exception exception) {
            Logger.loggerError("CaptureImage->isCapture->"+exception.toString());
	}

        if(null != player){
            try {
                player.realize();
                videoControl = (VideoControl)player.getControl("VideoControl");
                reLoadFooterMenu();
                ShortHandCanvas.IsNeedPaint();
                return true;
            } catch(Exception exception){
                Logger.loggerError("CaptureImage->isCapture->Player Not Realize"+exception.toString());
            }
        }
        return false;
    }

    public boolean isCapture(boolean isImage){
        SoundManager.getInstance().deinitialize();
        deInitialize(false);
        this.isImage = isImage;
        if(isImage){
            return isCaptureImage();
        } else return isCaptureAudio();
    }

     private boolean  createPlayer(String value){
        try{
            player = Manager.createPlayer(value);
        }catch(MediaException mediaException){
            player=null;
          Logger.loggerError("CaptureImage->CreatePlayer media ex->"+mediaException.toString());
            return false;
        } catch(Exception exception){
            Logger.loggerError("CaptureImage->CreatePlayer->"+exception.toString());
            return false;
        }
        Logger.loggerError("CaptureImage->CreatePlayer-player format>"+value);
        return true;
    }

     //CR 14465
    private boolean isCaptureAudio(){
        boolean isStarted = false;
         String[] value = new String[]{               
               
                "capture://audio?encoding=audio/amr&rate=8000",//501,311
                "capture://audio?encoding=audio/amr",//210
                 "capture://audio?encoding=pcm&rate=8000",//monte,star
                "capture://audio?encoding=audio/wav&rate=8000",
                "capture://audio?encoding=audio/x-wav&rate=8000",                
                "capture://audio?encoding=audio/x-amr&rate=8000",
                "capture://audio?encoding=audio/au&rate=8000",                
                "capture://audio?encoding=audio/basic&rate=8000",
                "capture://audio?encoding=pcm",
                 "capture://audio?encoding=audio/wav",
                "capture://audio?encoding=audio/x-wav",                
                "capture://audio?encoding=audio/x-amr",
                "capture://audio?encoding=audio/au",                
                "capture://audio?encoding=audio/basic",
                "capture://audio"
            };
        for(int i=0;i<value.length;i++){    
            if(createPlayer(value[i])){
                  if(value[i].indexOf("amr") == -1)
                    UiGlobalVariables.audioExtension  = "wav";
                  else
                    UiGlobalVariables.audioExtension  = "amr";                
                break;
            }
        }
         try{
            if(null != player){
                player.realize();
                recordControl = (RecordControl)player.getControl("RecordControl");
                Logger.debugOnError("recording type="+ recordControl.getContentType());

                byteArrayOutputStream = new ByteArrayOutputStream();
                recordControl.setRecordStream(byteArrayOutputStream);
                reLoadFooterMenu();
                ShortHandCanvas.IsNeedPaint();
                isStarted = true;
            } else {
                Logger.loggerError("Player Not supported ");
            }
        }catch(Exception exception){
            Logger.loggerError("CaptureImage->isCaptureAudio->"+exception.toString());
        }
         return isStarted;
    }

    private boolean camera(){
        try{
            if(null != videoControl){
                CustomCanvas.sHeader = CustomCanvas.getSecondaryHeader(Constants.options[55], "",0);
                videoControl.initDisplayMode(VideoControl.USE_DIRECT_VIDEO, ObjectBuilderFactory.getPCanvas());
                try {
                    videoControl.setDisplaySize(UISettings.formWidth-2, UISettings.formHeight -
                              (UISettings.headerHeight+UISettings.footerHeight));
                    videoControl.setDisplayLocation(0, UISettings.headerHeight);
                } catch (MediaException mediaException) {
                    Logger.loggerError("CaptureImage->loadCamera->mediaException->"+mediaException.toString());
                }
                player.start();
                videoControl.setVisible(true);
                //bug 14460
                isCurrentScreen = true;
                isCamera = true;
            }
        }catch(Exception exception){
            Logger.loggerError("CaptureImage->camera->"+exception.toString());
        }
        return isCamera;
    }

    //Cr 14465
    private boolean StartAudio(){
//        try{
            totoalTime = 0;
            isCurrentScreen = true;
            isAudio = true;
//        }catch(Exception exception){
//            Logger.loggerError("CaptureImage->audio->"+exception.toString());
//        }
        return isAudio;

    }

    public boolean loadCamera(){
        if(isImage){
            return camera();
        } else return StartAudio();
    }

    public byte commandAction(byte priority) {
        byte rByte = 3;
        if(priority == 0){
            captureImage();
        } else if(priority == 1){
            deInitialize(true);
        }
        return rByte;
    }

    public void drawCaptureImage(Graphics graphics){
        if(isImage){
            if(null != UiGlobalVariables.imagefile){
                if(isUpload){
                    CustomCanvas.drawProcessImage(graphics,imgrotType);
                } else {
                    int yPosition = UISettings.headerHeight;//+UISettings.secondaryHeaderHeight);
                    int height = UISettings.formHeight - (yPosition+UISettings.footerHeight+4);
                    if(UiGlobalVariables.imagefile.getHeight()<height)
                        yPosition += (height-UiGlobalVariables.imagefile.getHeight())/2;
                    graphics.drawImage(UiGlobalVariables.imagefile, (UISettings.formWidth-
                            UiGlobalVariables.imagefile.getWidth())/2, yPosition, Graphics.TOP|Graphics.LEFT);
                }
            }
        } else {
            //Cr 14465
           // Logger.debugOnError("drawCaptureImage>isUpload="+isUpload+"totoalTime="+totoalTime);
            if(isUpload){
                 CustomCanvas.drawProcessImage(graphics,imgrotType);
            } else {
                if(totoalTime>0 ){
                    String value = Utilities.getElapsedTime(totoalTime);
                   // Logger.debugOnError("timer value="+ value);
                    graphics.drawString(value, (UISettings.formWidth-graphics.getFont().stringWidth(value))/2,
                            (UISettings.formHeight/2)-(graphics.getFont().getHeight()/2), Graphics.LEFT|Graphics.TOP);
                }
            }
        }
    }

    public void reLoadFooterMenu(){
        if(isImage){
            if(null != UiGlobalVariables.imagefile){
                if(isUpload){
                    UISettings.lOByte = -1;
                    UISettings.rOByte = -1;
                } else {
                    UISettings.lOByte = 54; //Send Index
                    UISettings.rOByte = 57; //Discard Index
                }
            } else {
                UISettings.lOByte = 56; //Capture Index
                UISettings.rOByte = 22; //Back Index
            }
        } else {
            if(isUpload){
                UISettings.lOByte = -1;
                UISettings.rOByte = -1;
            } else if(totoalTime>0){
                UISettings.lOByte = 54; //Send Index
                UISettings.rOByte = 57; //Discard Index
            } else {
                UISettings.lOByte =  59; //record Index
                UISettings.rOByte =  8; //Cancel Index
            }
        }
    }


    public boolean pointerPressed(int xPosition, int yPosition, boolean isNotDrag,
            boolean isDragEnd, boolean isPressed){
        if(isNotDrag){
            if(isImage){
                captureImage();
            }
        }
        return false;
    }

    public void keyPressed(int keyCode){
        if(keyCode == UISettings.RIGHTOPTION){
            if(UISettings.rOByte >-1){ //Back and Discard Index
                if(UISettings.rOByte == 57){
                    isCapture(isImage);
                    loadCamera();
                } else {
                    deInitialize(true);
                }
            } 
        } else if(keyCode == UISettings.LEFTOPTION){
            if(UISettings.lOByte == 56){ // Capture Image 56
                capture();
            } else if(UISettings.lOByte == 59){ //Start Record; 59
              if(null != recordControl){
                 // reLoadFooterMenu();
                  try{
                      recordControl.startRecord();
                      if(player.getState()!=Player.STARTED)
                        player.start();
                      totoalTime = Calendar.getInstance().getTime().getTime();
                       reLoadFooterMenu();
                      ShortHandCanvas.IsNeedPaint();
                      startRotateImateTimer(20*1000);
                  }catch(Exception exception){
                      Logger.loggerError("CaptureImageAudio->StartRecord"+exception.toString());
                  }
                  ShortHandCanvas.IsNeedPaint();
              } else {
                  Logger.loggerError("CpatureImageAudio->Keypressed->RecordControl Not initialized");
              }
            } else if(UISettings.lOByte == 54){
                //CR 14465
                if((isImage && null != UiGlobalVariables.imagefile) || !isImage){
                    captureAudio();
                    isUpload = true;
                    reLoadFooterMenu();
                    startRotateImateTimer(100);
                    DownloadHandler downloadHandler = new DownloadHandler();
                    //CR 14465
                    downloadHandler.downloadImage(null,chatId, !isImage);
                    downloadHandler = null;
                } else {
                    deInitialize(true);
                }
            } 
        } else if(keyCode == UISettings.FIREKEY){ //CR 14465
            if(null == UiGlobalVariables.imagefile && isCamera){
                capture();
            }
        }
    }

    private void rotateImage(boolean stop){
        if(isUpload){
            rStart++;
            if(rStart >= 5){
                imgrotType++;
                if (imgrotType > 3) {
                    imgrotType = 0;
                }
                rStart = 0;
            }
        } else {
            //CR 14465
            if(!stop)
              capture();
        }
    }

    public void rotateScreen(){
        if(isCurrentScreen){
            if(isImage){
                CustomCanvas.sHeader = CustomCanvas.getSecondaryHeader(Constants.options[55], "",0);
            } else {
                CustomCanvas.sHeader = CustomCanvas.getSecondaryHeader(Constants.headerText[33], "",0);
            }
        }
    }

    //CR 14423
    public String SaveImage_Audio(String imageName){
        String fileLocation = null;
        try {
            UiGlobalVariables.byteArrayInputStream.reset();
            //Cr 14465, 14492
            if(isImage){
                fileLocation = Utilities.saveImage_Audio(UiGlobalVariables.byteArrayInputStream,
                        imageName, true, "jpeg");
            } else {
                fileLocation = Utilities.saveImage_Audio(UiGlobalVariables.byteArrayInputStream,
                        imageName, false, UiGlobalVariables.audioExtension);
            }
        } catch(Exception exception){
            Logger.loggerError("CaptureImage-SaveImage->"+exception.toString());
        }
        return fileLocation;
    }

    public void deInitialize(boolean isReEnable) {


        //CR 14465
        try{
            if(null != byteArrayOutputStream){
                byteArrayOutputStream.close();
                byteArrayOutputStream = null;
            }
        }catch(Exception exception){

        }

        Runtime.getRuntime().gc();

        isCamera = false;

        isAudio = false;
        
        totoalTime = 0;//mali
        
        stopPlayer();

        UiGlobalVariables.imagefile = null;

        rStart = 0;

        //Int
        imgrotType = 0;

        isUpload = false;

        isCurrentScreen = false;

        try{
            if(null != UiGlobalVariables.byteArrayInputStream){
                UiGlobalVariables.byteArrayInputStream.close();
                UiGlobalVariables.byteArrayInputStream = null;
            }
        }catch(Exception exception){
            Logger.loggerError("CaptureImage->deinitialize->StreamClose"+exception.toString());
        }

        if(isReEnable){
            iMenuHandler.enableUpSelection();
        }
    }

    private void stopPlayer(){

        stopRotateImageTimer();

        isCamera = false;
        isAudio = false;
        videoControl = null;

        //CR 14465
        try{
            if(null != recordControl){
                recordControl.stopRecord();
                recordControl = null;
            }
        }catch(Exception exception){
            Logger.loggerError("CaptureImage->stopPlayer->recoreControl"+exception.toString());
        }
        
        try{
            if(null != player){
                if(player.getState() == Player.STARTED){
                    player.stop();
                }
//                if(player.getState() == Player.PREFETCHED){
                    player.deallocate();
//                }
                if(player.getState() == Player.REALIZED  || player.getState() == Player.UNREALIZED){
                    player.close();
                }
                player = null;
            }
        }catch(Exception exception){
            Logger.loggerError("CaptureImage->stopPlayer->Player"+exception.toString());
        }
    }

    private void stopRotateImageTimer(){
       // Logger.debugOnError("timer stop");
        if(null != rotateImageTimer){
            rotateImageTimer.cancel();
            rotateImageTimer = null;
        }
    }


    private void startRotateImateTimer(int time){
        stopRotateImageTimer();
                Logger.debugOnError("timer stop before start");

        rotateImageTimer = new Timer();
        rotateImageTimer.schedule(new DisplayImageTimer(), 0, time);
    }

    private boolean setImageData(String encodeFormat){
        boolean isSecurity = false;
        try {
            UiGlobalVariables.byteArrayInputStream = new ByteArrayInputStream(videoControl.getSnapshot(encodeFormat));
            UiGlobalVariables.audioExtension = null;//mali
        } catch(SecurityException securityException){
            Logger.loggerError("Encoding format security Exception "+securityException.toString());
            isSecurity = true;
        } catch(Exception e){
            Logger.loggerError("Encoding format not supported "+encodeFormat);
        }
        return isSecurity;
    }

    private void capture(){
        if(isImage){
            captureImage();
        } else captureAudio();
    }

    private void captureAudio(){
        if(null != recordControl){
            try{
                        Logger.debugOnError("timer stop after capture aud/img");
                        totoalTime = 1;

                stopRotateImageTimer();                
//                UiGlobalVariables.audioExtension  = "amr";
//                Logger.debugOnError("recording type="+ recordControl.getContentType());
//                if(recordControl.getContentType().indexOf("amr") == -1);
//                    UiGlobalVariables.audioExtension  = "wav";
                    
                String manufacture =  Utilities.getManufacture();
                if(null != manufacture && manufacture.toLowerCase().indexOf("samsung") == -1){
                    recordControl.stopRecord();
                    recordControl.commit();
                } else {
                    recordControl.commit();
                    recordControl.stopRecord();
                }

                recordControl = null;

                stopPlayer();
                Logger.loggerError("Recorded Bytes"+byteArrayOutputStream.size());
//                byteArrayOutputStream.reset();
                UiGlobalVariables.byteArrayInputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());

                byteArrayOutputStream.close();
                byteArrayOutputStream = null;

                reLoadFooterMenu();
                ShortHandCanvas.IsNeedPaint();
                return;

            }catch(Exception exception){
                Logger.loggerError("Capture Audio - Stop Player "+exception.toString());
            }
            deInitialize(true);
            ShortHandCanvas.IsNeedPaint();
        }
    }

    private void captureImage(){
        if(null != videoControl){
            try {
                int height = (UISettings.formHeight-(UISettings.headerHeight+
                        UISettings.footerHeight));
                String encodings = System.getProperty("video.snapshot.encodings");
                if(null != encodings){
                    boolean isSecurity = false;
                    String[] encodeFormat = new String[]{
                        "encoding=image/jpeg&quality=100&width="+(UISettings.formWidth-2)+"&height="+height,
                        "encoding=jpeg&quality=100&width="+(UISettings.formWidth-2)+"&height="+height,

                        "encoding=image/jpeg&width="+(UISettings.formWidth-2)+"&height="+height,
                        "encoding=jpeg&width="+(UISettings.formWidth-2)+"&height="+height,
                        
                        "encoding=image/jpeg",
                        "encoding=jpeg",
                        null};
                    for(int i=0;i<encodeFormat.length;i++){
                        isSecurity = setImageData(encodeFormat[i]);
                        if(isSecurity || null != UiGlobalVariables.byteArrayInputStream){
                            break;
                        }
                    }
                }
                if(null != UiGlobalVariables.byteArrayInputStream){
                    //bug 14452
                    UiGlobalVariables.imagefile = ImageHelper.createThumbnail(UiGlobalVariables.byteArrayInputStream, 
                            UISettings.formWidth-2, height, false);
                    stopPlayer();
                }
                if(null != UiGlobalVariables.imagefile){
                    UiGlobalVariables.byteArrayInputStream.reset();
                    reLoadFooterMenu();
                    ShortHandCanvas.IsNeedPaint();
                    return;
                } 
            } catch(Exception exception){
                Logger.loggerError("CaptureImage->captureImage->"+exception.toString());
            }
            deInitialize(true);
            ShortHandCanvas.IsNeedPaint();
        }
    }

    public boolean isAudioScreen() {
        return isAudio;
    }

    class DisplayImageTimer extends TimerTask{
                    boolean started = false;
        public void run(){
            if(!started)
                started = true; 
            else
                started= false;
            rotateImage(started);
            ShortHandCanvas.IsNeedPaint();
        }
    }
}
