
import java.util.Enumeration;
import java.util.Vector;
import javax.microedition.pim.Contact;
import javax.microedition.pim.ContactList;
import javax.microedition.pim.PIM;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Sasi
 */
public class Contacts {


    private static String[] getContactDetails(){
        String[] values = null;
            PIM pim = PIM.getInstance();
             try{
                String[] list = pim.listPIMLists(PIM.CONTACT_LIST);
                int count = list.length;
                Logger.debugOnError("Number of contact List:" + count);
                Contact contact = null;
                ContactList addressbook = null;
                Enumeration items = null;
                int nameCount = 0;
                int telCount = 0;
                String personName = null;
                String[] nameField;
                Vector value = new Vector();
                int supportedFormats = -1;
                for(int i=0;i<count;i++){
                    addressbook = (ContactList)pim.openPIMList(PIM.CONTACT_LIST, PIM.READ_ONLY, list[i]);
                    if(supportedFormats == -1){
                        items = addressbook.items();
                        Logger.loggerError("FORMATTED_NAME "+addressbook.isSupportedField(Contact.FORMATTED_NAME)+"\n"+
                                "NAME "+addressbook.isSupportedField(Contact.NAME)+"\n"+
                                "NAME_FAMILY "+addressbook.isSupportedField(Contact.NAME_FAMILY) + "\n"+
                                "NAME_GIVEN "+addressbook.isSupportedField(Contact.NAME_GIVEN)+"\n" +
                                "NAME_OTHER "+addressbook.isSupportedField(Contact.NAME_OTHER)+"\n"+
                                "NAME_SUFFIX "+addressbook.isSupportedField(Contact.NAME_SUFFIX)+"\n"+
                                "NAME_PREFIX "+addressbook.isSupportedField(Contact.NAME_PREFIX)+ "\n"+                                
                                "NICKNAME "+addressbook.isSupportedField(Contact.NICKNAME));
                        if(addressbook.isSupportedField(Contact.FORMATTED_NAME)) {
                            supportedFormats = Contact.FORMATTED_NAME;
                        } else if(addressbook.isSupportedField(Contact.NAME)) {
                            supportedFormats = Contact.NAME;
                        } else if(addressbook.isSupportedField(Contact.NAME_GIVEN)) {
                            supportedFormats = Contact.NAME_GIVEN;
                        } else if(addressbook.isSupportedField(Contact.NAME_OTHER)) {
                            supportedFormats = Contact.NAME_OTHER;
                        } else if(addressbook.isSupportedField(Contact.NAME_PREFIX)) {
                            supportedFormats = Contact.NAME_PREFIX;
                        } else if(addressbook.isSupportedField(Contact.NAME_SUFFIX)) {
                            supportedFormats = Contact.NAME_SUFFIX;
                        }
                    }

                    while (items.hasMoreElements()) {
                        contact = (Contact)items.nextElement();
                        telCount = contact.countValues(Contact.TEL);
                        nameCount = contact.countValues(supportedFormats);
           

                        if (telCount > 0 && nameCount > 0)
                        {
                            if (supportedFormats == 105) {//Contact.FORMATTED_NAME
                                personName = contact.getString(supportedFormats, 0);
                                for (int k = 0; k < telCount; k++) {
                                    value.addElement(contact.getString(Contact.TEL, k)+"^"+personName);
                                  //  Logger.debugOnError("NAME = : "+ personName + " and  NUM =  : " + contact.getString(Contact.TEL, k));
                                }
                            } else if (supportedFormats == 106) {//Contact.NAME
                                nameField = contact.getStringArray(supportedFormats, 0);
                                //13751
                                for (int k = 0; k < telCount; k++) {
                                    if (nameField[Contact.NAME_GIVEN] != null && nameField[Contact.NAME_FAMILY] != null){
                                        value.addElement(contact.getString(Contact.TEL, k)+"^"+nameField[Contact.NAME_GIVEN]+" "+nameField[Contact.NAME_FAMILY]);
                                        Logger.debugOnError("Contact.NAME_GIVEN, Contact.NAME_FAMILY: "+ nameField[Contact.NAME_GIVEN]+" "+nameField[Contact.NAME_FAMILY ]  +   ",  NUMBER = " + contact.getString(Contact.TEL, k));
                                    }
                                    //13751
                                    else if(nameField[Contact.NAME_FAMILY] != null) {
                                        value.addElement(contact.getString(Contact.TEL, k)+"^"+nameField[Contact.NAME_FAMILY]);
                                     //   Logger.debugOnError("Contact.NAME_FAMILY:"+nameField[Contact.NAME_FAMILY] + ",  NUMBER = " + contact.getString(Contact.TEL, k) );
                                    }
                                    else if(nameField[Contact.NAME_GIVEN] != null) {
                                        value.addElement(contact.getString(Contact.TEL, k)+"^"+nameField[Contact.NAME_GIVEN]);
                                    //    Logger.debugOnError("Contact.NAME_GIVEN:"+nameField[Contact.NAME_GIVEN] + "AND NUMBER = " + contact.getString(Contact.TEL, k) );
                                    }
                                                                    
                                }
                            }
                        }
                    }
                }
                if(value.size()>0){
                    Logger.debugOnError("Total Contacts= " + value.size() + "\n");
                    values = new String[value.size()];
                    value.copyInto(values);
                }
            } catch (SecurityException e) {
                Logger.loggerError("Set Contact Details Security exception:" + e.toString());
            } catch (Exception e){
                Logger.loggerError("Set Contact Details exception:" + e.toString());

            }
            //values = new String[]{"18587037686^fer","918754415795^sasi","18583353330^carl","919626433266^mathan","919566005444^test"};
            return values;
    }

    public static String[] getSearchedValues(String searchValue){
        String[] values = null;
            PIM pim = PIM.getInstance();
             try{
                String[] list = pim.listPIMLists(PIM.CONTACT_LIST);
                int count = list.length;
                Contact contact = null;
                ContactList addressbook = null;
                Enumeration items = null;
                int nameCount = 0;
                int telCount = 0;
                String personName = null;
                Vector num = new Vector();
                for(int i=0;i<count;i++){
                    addressbook = (ContactList)pim.openPIMList(PIM.CONTACT_LIST, PIM.READ_ONLY, list[0]);
                    items = addressbook.items(searchValue);
                    while (items.hasMoreElements()) {
                        contact = (Contact)items.nextElement();
                        telCount = contact.countValues(Contact.TEL);
                        nameCount = contact.countValues(Contact.FORMATTED_NAME);
                        if (telCount > 0 && nameCount > 0) {
                            personName = contact.getString(Contact.FORMATTED_NAME, 0);
                            for (int k = 0; k < telCount; k++) {
                                num.addElement(personName +" - "+contact.getString(Contact.TEL, k));
                            }
                        }
                    }
                }
                values = new String[num.size()];
                num.copyInto(values);
            } catch (SecurityException e) {
                Logger.loggerError("Contact Retrieve Security Exception "+e.toString());
            } catch (Exception e){
                Logger.loggerError("Contact Retrieve Exception "+e.toString());
            }
            return values;
    }




//    public static String[] getName(){
//        return contactName;
//    }
//
//    public static String[] getNumber(){
//        return  contactNumber;
//    }

    private static String[] setRecordStore(RecordStoreParser recordStoreParser, String displayFormat){
        String[] values = getContactDetails();
        int count =0;
        if(null != values && (count= values.length)>0){
            String[] sValue = null;
            for(int i=0;i<count;i++){
                recordStoreParser.addRecord(values[i].getBytes(), 0, values[i].getBytes().length, true);
                sValue = Utilities.split(values[i], "^");
                values[i] = Utilities.replace(displayFormat, "[cell]", sValue[0]);
                values[i] = Utilities.replace(values[i], "[name]", sValue[1]);
            }
        }
        return values;
    }

    public static boolean isContactPresent(){
        boolean isNotPresent = true;
        RecordStoreParser recordStoreParser = new RecordStoreParser();
        if(null != recordStoreParser){
            if(!recordStoreParser.openRecordStore(RecordManager.msContact, false, false, false)){
                if(recordStoreParser.getNumRecords()>0)
                    isNotPresent = false;
            }
            recordStoreParser.closeRecordStore();
            recordStoreParser = null;
        }
        return isNotPresent;
    }

    public static String getUploadcontacts(){
//        boolean isRefresh = isContactPresent();
        RecordStoreParser recordStoreParser = new RecordStoreParser();
        String contacts = "";
        int count = 0;
//        String[] sValue = null;
        if(null != recordStoreParser){
            RecordStoreParser.deleteRecordStore(RecordManager.msContact, true);
            recordStoreParser.openRecordStore(RecordManager.msContact, true,
                   false, false);
            String displayFormat = "[name],[cell]\n";
//            if(isRefresh) {
                String[] contact = setRecordStore(recordStoreParser, displayFormat);
                if(null != contact && (count=contact.length)>0){
                    for(int i=0;i<count;i++){
                        contacts += contact[i];
                    }
                }
//            } else {
//               count = recordStoreParser.getNumRecords();
//               if(count>0){
//                   byte[] values = null;
//                   String temp = null;
//
//                   for(int i=1;i<=count;i++){
//                        values = recordStoreParser.getRecord(i);
//                        sValue = Utilities.split(new String(values), "^");
//                        temp = Utilities.replace(displayFormat, "[cell]", sValue[0]);
//                        contacts += Utilities.replace(temp, "[name]", sValue[1]);
//                   }
//               }
//            }
        }
        recordStoreParser.closeRecordStore();
        recordStoreParser = null;
        return contacts;
    }

    public static String[] getContactList(boolean isRefresh, String displayFormat){
        String[] contacts = null;
      //  if(null == displayFormat)
          //bug 13728

            displayFormat = "[name] - [cell]";
        RecordStoreParser recordStoreParser = new RecordStoreParser();
        if(null != recordStoreParser){
           if(isRefresh)
               RecordStoreParser.deleteRecordStore(RecordManager.msContact, true);
           recordStoreParser.openRecordStore(RecordManager.msContact, true,
                   false, false);
           if(isRefresh){
               contacts = setRecordStore(recordStoreParser, displayFormat);
           } else {
               int count = recordStoreParser.getNumRecords();
               if(count>0){
                   contacts = new String[count];
                   byte[] values = null;
                   String[] sValue = null;
                   for(int i=1;i<=count;i++){
                        values = recordStoreParser.getRecord(i);
                        sValue = Utilities.split(new String(values), "^");
                        contacts[i-1] = Utilities.replace(displayFormat, "[cell]", sValue[0]);
                        contacts[i-1] = Utilities.replace(contacts[i-1], "[name]", sValue[1]);
                   }
               }
           }
        }
        recordStoreParser.closeRecordStore();
        recordStoreParser = null;
        return contacts;
    }

}
