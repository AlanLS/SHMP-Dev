
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import javax.microedition.lcdui.Image;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sasi
 */
public class UiGlobalVariables {

    public static Image imagefile = null;
    
    public static ByteArrayInputStream byteArrayInputStream = null;

//    public static ByteArrayOutputStream byteArrayOutputStream = null;

    public static String fileLocation = null;

    public static String audioExtension = "wav";
    public static InputStream inputStream = null;

}
