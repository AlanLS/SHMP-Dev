public class UrlAction {
    
    //URl
    private String url;
    
    //Url Id
    private int id;
    
    //GoTo Id
    private int goId;

    public int getGoId() {
        return goId;
    }

    public int getId() {
        return id;
    }

    public String getUrl() {
        return url;
    }

    public void setGoId(int goId) {
        this.goId = goId;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setUrl(String url) {
        this.url = url;
    }
    
}
