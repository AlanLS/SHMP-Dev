
import jg.JgCanvas;

import javax.microedition.lcdui.Display;
import javax.microedition.midlet.MIDlet;

/**
 * DO NOT HAND MODIFY THIS CLASS, IT WILL BE OVERWRITTEN FOR EACH BUILD.
 */
public class Shorthand extends MIDlet {
    private JgCanvas canvas;

    public void startApp() {
        if (canvas == null) {
            canvas = new ShortHandCanvas(this);
            Display.getDisplay(this).setCurrent(canvas);
        } else {
            canvas.showNotify();
        }
    }

    public void destroyApp(boolean unconditional) {
       //#if VERBOSELOGGING
       //|JG|Logger.loggerError("Shorthand->destroyApp");
       //#endif
       //CR 13278
//       byte exitPressed = ObjectBuilderFactory.GetKernel().exitShorthand();
//       if(exitPressed == 2){
        Logger.loggerError("Shorthand->destroyApp "+unconditional);
//        ShortHandCanvas.currentDate = Long.parseLong(Utilities.getCurrentDateHHMMDDYYFormat());
        canvas.postSystemEvent(JgCanvas.SYSTEM_EVENT_EXIT);
//       } else canvas.showNotify();
    }

    public void pauseApp() {
//        canvas.postSystemEvent(JgCanvas.SYSTEM_EVENT_INTERRUPT);
        canvas.hideNotify();
    }
    
}
